// Copyright 2013
// Author: Christopher Van Arsdale

package env

import (
	"log"
	"path"
	"strings"
)

type InputEnv struct {
	Root       string
	BuildFiles []string
	CCFlags    []string
	Compiler   string
	ObjectDir  string
}

func NewInputEnv() InputEnv {
	var env InputEnv
	env.BuildFiles = make([]string, 0)
	env.Compiler = "g++"
	env.ObjectDir = "objs"
	env.CCFlags = make([]string, 0)
	env.CCFlags = append(env.CCFlags, "-Wall")
	return env
}

func (i *InputEnv) CCCompileFlags() string {
	if i.CCFlags == nil {
		return ""
	}
	return strings.Join(i.CCFlags, " ")
}

func (i *InputEnv) FullTargetName(current_dir string, name string) string {
	pieces := strings.Split(name, ":")
	if len(pieces) != 2 {
		log.Fatal("Invalid target: ", name)
	}

	dir := ""
	if strings.HasPrefix(pieces[0], "//") {
		dir = pieces[0][2:]
	} else {
		dir = path.Join(GetDir(current_dir), pieces[0])
	}

	return "//" + dir + ":" + pieces[1]
}

func RelativePath(current_node string, name string) string {
	pieces := strings.Split(current_node, ":")
	if len(pieces) != 2 || !strings.HasPrefix(pieces[0], "//") {
		log.Fatal("Invalid target: ", name)
	}
	return path.Join(pieces[0][2:], name)
}

func (i *InputEnv) FullTarget(current_target string, name string) string {
	return i.FullTargetName(i.ComputeBuildFile("", current_target), name)
}

func GetDir(dir string) string {
	dir = path.Dir(dir)
	if dir == "." {
		return ""
	}
	return dir
}

func (i *InputEnv) ComputeBuildFileDir(current string, target string) string {
	pieces := strings.Split(target, ":")
	if len(pieces) != 2 {
		log.Fatal("Bad target: ", target)
	}
	if strings.HasPrefix(pieces[0], "//") {
		return pieces[0][2:]
	}
	return path.Join(GetDir(current), pieces[0])
}

func (i *InputEnv) ComputeBuildFile(current string, target string) string {
	return path.Join(i.ComputeBuildFileDir(current, target), "BUILD")
}

func (i *InputEnv) ComputeRootedDir(full_target string) string {
	if !strings.HasPrefix(full_target, "//") {
		log.Fatal("Invalid full target path.")
	}
	pieces := strings.Split(full_target, ":")
	return pieces[0][2:]
}

func (i *InputEnv) FullPath(file string) string {
	return path.Join(i.Root, file)
}
