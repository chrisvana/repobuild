// Copyright 2013
// Author: Christopher Van Arsdale

package main

import (
	"./env"
	"./generator"
	"./parser"
	"flag"
	"fmt"
	"io/ioutil"
	"os"
)

func usage() {
	fmt.Fprintf(os.Stderr, "usage: repobuild path/to/BUILD [...BUILD] \n")
	flag.PrintDefaults()
	os.Exit(2)
}

func main() {
	flag.Usage = usage
	flag.Parse()

	args := flag.Args()
	if len(args) < 1 {
		fmt.Println("Missing build files.")
		os.Exit(1)
	}

	env_input := env.NewInputEnv()
	env_input.Root, _ = os.Getwd()
	for _, file := range args {
		env_input.BuildFiles = append(env_input.BuildFiles, file)
	}
	graph := parser.ParseBuildDeps(env_input)
	out := []byte(generator.GenerateMakefile(env_input, graph))
	ioutil.WriteFile("Makefile", out, 0644)
}
