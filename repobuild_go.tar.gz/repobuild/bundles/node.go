// Copyright 2013
// Author: Christopher Van Arsdale

package bundles

import (
	"log"
)

type GetRaw interface {
	GetRawNode() *RawNode
}

type RawNode struct {
	Name         string
	FullName     string
	Dependencies []string
}

func (r *RawNode) GetRawNode() *RawNode {
	return r
}

type GraphNode struct {
	Raw          *RawNode
	FullNode     interface{}
	Dependencies []*GraphNode
	AllDeps      map[string]*GraphNode
}

type Graph struct {
	Nodes []*GraphNode
	Named map[string]*GraphNode
}

func NewGraph() *Graph {
	r := new(Graph)
	r.Nodes = make([]*GraphNode, 0)
	return r
}

func (g *Graph) NewGraphNode(i interface{}) *GraphNode {
	r := new(GraphNode)
	r.FullNode = i
	r.Raw = i.(GetRaw).GetRawNode()
	g.Nodes = append(g.Nodes, r)
	return r
}

func (g *Graph) ComputeGraph() {
	g.Named = make(map[string]*GraphNode)
	for _, n := range g.Nodes {
		n.AllDeps = make(map[string]*GraphNode)
		n.Dependencies = make([]*GraphNode, 0)
		g.Named[n.Raw.FullName] = n
	}
	for _, n := range g.Nodes {
		for _, dep_name := range n.Raw.Dependencies {
			if _, ok := g.Named[dep_name]; !ok {
				log.Fatal("Unknown target: ", dep_name)
			}
			n.Dependencies = append(n.Dependencies, g.Named[dep_name])
		}
	}
	for _, n := range g.Nodes {
		parents := make(map[string]bool)
		ExpandDeps(n, n, &parents)
	}
}

func ExpandDeps(node *GraphNode, dep *GraphNode, parents *map[string]bool) {
	if _, ok := (*parents)[dep.Raw.FullName]; ok {
		log.Fatal("Recursive dependencies: ", parents)
	}
	if dep != node { // should only be true for the first call.
		node.AllDeps[dep.Raw.FullName] = dep
	}

	(*parents)[dep.Raw.FullName] = true
	for _, dep := range dep.Dependencies {
		ExpandDeps(node, dep, parents)
	}
	delete(*parents, dep.Raw.FullName)
}
