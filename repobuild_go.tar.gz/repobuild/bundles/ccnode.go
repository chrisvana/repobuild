// Copyright 2013
// Author: Christopher Van Arsdale

package bundles

type CCLibrary struct {
	RawNode
	CC_Sources []string
	CC_Headers []string
}

func (c *CCLibrary) GetRawNode() *RawNode {
	return &c.RawNode
}

type CCBinary struct {
	RawNode
	CCLibrary
}

func (c *CCBinary) GetRawNode() *RawNode {
	return &c.RawNode
}
