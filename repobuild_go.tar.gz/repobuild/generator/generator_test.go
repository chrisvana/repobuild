// Copyright 2013
// Author: Christopher Van Arsdale

package generator

import (
	"../env"
	"../parser"
	"fmt"
	"io/ioutil"
	"os"
	"testing"
)

func TestGenMakefile(t *testing.T) {
	env_input := env.NewInputEnv()
	env_input.Root, _ = os.Getwd()
	env_input.Root += "/../parser/test"
	env_input.BuildFiles = append(env_input.BuildFiles, "BUILD")
	graph := parser.ParseBuildDeps(env_input)
	if len(graph.Nodes) != 7 {
		t.Error("Unexpected number of nodes: ", len(graph.Nodes))
		return
	}

	out := GenerateMakefile(env_input, graph)
	golden, _ := ioutil.ReadFile("testdata/Makefile.golden")
	if string(golden) != out {
		fmt.Print(out)
		t.Error("Golden file mismatch, run diff, size: ",
			len(out), " vs ", len(string(golden)))
	}
}
