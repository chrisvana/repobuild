repobuild
=========

Build tool for my projects.

# Install instructions:

```bash
git clone https://github.com/chrisvana/repobuild.git /tmp/repobuild
cd /tmp/repobuild
go build
sudo mkdir /usr/local/repobuild
sudo cp -R ./repobuild /usr/local/repobuild

# Update your PATH (add :/usr/local/repobuild)
```
