// Copyright 2013
// Author: Christopher Van Arsdale

package parser

import (
	//  "log"
	"../env"
	"os"
	"testing"
)

func ExpectName(t *testing.T, actual string, expected string) {
	if expected != actual {
		t.Error("Expected: ", expected, ". Actual: ", actual)
	}
}

func TestParseBuildDeps(t *testing.T) {
	env_input := env.NewInputEnv()
	env_input.Root, _ = os.Getwd()
	env_input.Root += "/test"
	env_input.BuildFiles = append(env_input.BuildFiles, "BUILD")
	graph := ParseBuildDeps(env_input)

	if len(graph.Nodes) != 7 {
		t.Error("Unexpected number of nodes: ", len(graph.Nodes))
	}
	ExpectName(t, graph.Nodes[0].Raw.FullName, "//:foo")
	ExpectName(t, graph.Nodes[1].Raw.FullName, "//:bar")
	ExpectName(t, graph.Nodes[2].Raw.FullName, "//:main")
	ExpectName(t, graph.Nodes[3].Raw.FullName, "//a:foo_pred_a")
	ExpectName(t, graph.Nodes[4].Raw.FullName, "//a:bar_pred_a")
	ExpectName(t, graph.Nodes[5].Raw.FullName, "//b:foo_pred_b")
	ExpectName(t, graph.Nodes[6].Raw.FullName, "//b:bar_pred_b")
}
