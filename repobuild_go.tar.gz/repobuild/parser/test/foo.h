// Copyright 2013
// Author: Christopher Van Arsdale

namespace test {

extern void RunFooTest();

}  // namespace test
