// Copyright 2013
// Author: Christopher Van Arsdale

namespace a {

extern void RunFooA();

}  // namespace a
