// Copyright 2013
// Author: Christopher Van Arsdale

#include <iostream>

namespace a {

void RunBarA() {
  std::cout << "BarA" << std::endl;
}

}  // namespace a
