// Copyright 2013
// Author: Christopher Van Arsdale

#include <iostream>
#include "foo.h"

namespace a {

void RunFooA() {
  std::cout << "FooA" << std::endl;
}

}  // namespace a
