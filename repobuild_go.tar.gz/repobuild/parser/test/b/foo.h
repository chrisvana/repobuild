// Copyright 2013
// Author: Christopher Van Arsdale

namespace b {

extern void RunFooB();

}  // namespace b
