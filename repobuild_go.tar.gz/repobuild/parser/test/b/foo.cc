// Copyright 2013
// Author: Christopher Van Arsdale

#include <iostream>
#include "foo.h"

namespace b {

void RunFooB() {
  std::cout << "FooB" << std::endl;
}

}  // namespace b
