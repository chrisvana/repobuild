// Copyright 2013
// Author: Christopher Van Arsdale

package parser

import (
	"../bundles"
	"../env"
	"container/list"
)

func ParseBuildDeps(env env.InputEnv) *bundles.Graph {
	g := new(bundles.Graph)

	l := list.New()
	for _, f := range env.BuildFiles {
		l.PushBack(f)
	}

	files := make(map[string]bool)
	for e := l.Front(); e != nil; e = e.Next() {
		file := e.Value.(string)
		if _, ok := files[file]; ok {
			continue
		}

		files[file] = true
		for key, _ := range LoadFile(file, env, g) {
			l.PushBack(key)
		}
	}
	g.ComputeGraph()
	return g
}

func LoadFile(filename string, env env.InputEnv,
	g *bundles.Graph) map[string]bool {

	// All types.
	driver := NewJsonDriver()

	// TODO, move this to bundles/...
	{ // cc_library
		var t bundles.CCLibrary
		driver.AddType("cc_library", t)
	}
	{ // cc_binary
		var t bundles.CCBinary
		driver.AddType("cc_binary", t)
	}

	files := make(map[string]bool)
	ParseJsonFile(env.FullPath(filename), driver)
	for _, t := range driver.Types {
		for _, o := range t.Objects {
			gnode := g.NewGraphNode(o)
			gnode.Raw.FullName = env.FullTargetName(filename, ":"+gnode.Raw.Name)
			for i, d := range gnode.Raw.Dependencies {
				files[env.ComputeBuildFile(filename, d)] = true
				gnode.Raw.Dependencies[i] = env.FullTarget(gnode.Raw.FullName, d)
			}
		}
	}

	return files
}
