// Copyright 2013
// Author: Christopher Van Arsdale

package parser

import (
	"bufio"
	"encoding/json"
	"io"
	"log"
	"os"
	"reflect"
	"strings"
)

type JsonSingleType struct {
	Type    reflect.Type
	Objects []interface{}
}

func NewJsonSingleType(mytype interface{}) *JsonSingleType {
	r := new(JsonSingleType)
	r.Type = reflect.TypeOf(mytype)
	r.Objects = make([]interface{}, 0)
	return r
}

type JsonDriver struct {
	Types map[string]*JsonSingleType
}

func NewJsonDriver() *JsonDriver {
	r := new(JsonDriver)
	r.Types = make(map[string]*JsonSingleType)
	return r
}

func (j *JsonDriver) AddType(name string, mytype interface{}) {
	j.Types[name] = NewJsonSingleType(mytype)
}

func (j *JsonDriver) run(key string, data []byte) {
	if _, ok := j.Types[key]; !ok {
		log.Fatal("Unknown type: ", key)
	}
	next := reflect.New(j.Types[key].Type)
	inter := next.Interface()
	json.Unmarshal(data, &inter)
	j.Types[key].Objects = append(j.Types[key].Objects, inter)
}

func ParseJsonStream(input io.Reader, driver *JsonDriver) {
	scanner := bufio.NewScanner(input)
	filtered := ""
	for scanner.Scan() {
		fields := strings.Fields(scanner.Text())
		if len(fields) > 0 &&
			!strings.HasPrefix(fields[0], "//") &&
			!strings.HasPrefix(fields[0], "#") {
			filtered += scanner.Text() + "\n"
		}
	}

	var temp interface{}
	dec := json.NewDecoder(strings.NewReader(filtered))
	err := dec.Decode(&temp)
	if temp == nil && err == io.EOF {
		return
	}
	if err != nil {
		log.Fatal(err)
	}
	for _, val := range temp.([]interface{}) {
		for k, i := range val.(map[string]interface{}) {
			out, err2 := json.Marshal(i)
			if err2 != nil {
				log.Fatal(err2)
			}
			driver.run(k, out)
		}
	}
}

func ParseJsonFile(filename string, driver *JsonDriver) {
	file, err := os.Open(filename)
	if err != nil {
		log.Fatal(err)
	}
	ParseJsonStream(file, driver)
}
