// Copyright 2013
// Author: Christopher Van Arsdale

package parser

import (
	"strings"
	"testing"
)

type FooType struct {
	Name string
}

func TestParseStream(t *testing.T) {
	const input = `
[{ "Foo": { "Name" : "Bar" } },
 // ignore comment line.
 { "Foo" : {} }
]`
	driver := NewJsonDriver()
	var footype FooType
	driver.AddType("Foo", footype)
	ParseJsonStream(strings.NewReader(input), driver)

	foo_driver := driver.Types["Foo"]
	if foo_driver == nil {
		t.Error("Missing Foo")
		return
	}
	if len(foo_driver.Objects) != 2 {
		t.Errorf("Foo length: %d", len(foo_driver.Objects))
		return
	}
	if foo_driver.Objects[0].(*FooType).Name != "Bar" {
		t.Error("Bad foo: ", foo_driver.Objects[0])
		return
	}
}
